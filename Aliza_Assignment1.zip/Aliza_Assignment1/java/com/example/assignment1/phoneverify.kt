package com.example.assignment1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class phoneverify : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phoneverify)
    }
}